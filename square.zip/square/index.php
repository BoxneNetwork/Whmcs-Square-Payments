<?php

use WHMCS\Database\Capsule;

define("CLIENTAREA", true);
require_once("../../../init.php");
include("../../../includes/gatewayfunctions.php");
include("../../../invoicefunctions.php");

$gatewaymodule = "square";
$gateway = getGatewayVariables($gatewaymodule);

$order = base64_decode($_POST["order"]);
$orderDetails = array();
$orderDetails = unserialize($order);
if ($order) {
    $_SESSION['squareamount'] = $orderDetails['amount'];
    $_SESSION['squarecurrency'] = $orderDetails['currency'];
    $_SESSION['squareinvoiceid'] = $orderDetails['invoiceid'];
}

$invoiceid = checkCbInvoiceID($orderDetails['invoiceid'], $gateway["name"]);

if (!$invoiceid)
    die("Invalid order used");


$ca = new WHMCS_ClientArea();
$ca->setPageTitle("Squareup Payment");
$ca->addToBreadCrumb('index.php', $orderDetails['globalsystemname']);
$ca->initPage();
$ca->assign('systemurl', $orderDetails['systemurl']);
$ca->assign('params', $orderDetails);
$ca->setTemplate('square');
$ca->output();
?>