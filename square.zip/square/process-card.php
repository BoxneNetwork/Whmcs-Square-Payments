<?php

use Illuminate\Database\Capsule\Manager as Capsule;

require_once("../../../init.php");
require_once("../../../includes/gatewayfunctions.php");
require_once("../../../includes/invoicefunctions.php");

$gatewaymodule = "square";
$gateway = getGatewayVariables($gatewaymodule);
require_once 'vendor/autoload.php';

# Replace these values. You probably want to start with your Sandbox credentials
# to start: https://docs.connect.squareup.com/articles/using-sandbox/
# The ID of the business location to associate processed payments with.
# If you're testing things out, use a sandbox location ID.
#
# See [Retrieve your business's locations](https://docs.connect.squareup.com/articles/getting-started/#retrievemerchantprofile)
# for an easy way to get your business's location IDs.
$testMode = $gateway['testMode'];
if ($testMode == 'on') {
    $accesstoken = $gateway['sandbox_access_token'];
    $applicationid = $gateway['sandbox_applicationId'];
} else {
    $accesstoken = $gateway['access_token'];
    $applicationid = $gateway['applicationId'];
}
$location_id = $gateway['locationid'];

# The access token to use in all Connect API requests. Use your *sandbox* access
# token if you're just testing things out.
$access_token = $accesstoken;

# Helps ensure this code has been reached via form submission
if ($_SERVER['REQUEST_METHOD'] != 'POST') {
    error_log("Received a non-POST request");
    echo "Request not allowed";
    http_response_code(405);
    return;
}

# Fail if the card form didn't send a value for `nonce` to the server
$nonce = $_POST['nonce'];
if (is_null($nonce)) {
    echo "Invalid card data";
    http_response_code(422);
    return;
}

$transaction_api = new \SquareConnect\Api\TransactionApi();

$request_body = array(
    "card_nonce" => $nonce,
    # Monetary amounts are specified in the smallest unit of the applicable currency.
    # This amount is in cents. It's also hard-coded for $1.00, which isn't very useful.
    "amount_money" => array(
        "amount" => ($_SESSION['squareamount'] * 100),
        "currency" => $_SESSION['squarecurrency']
    ),
    # Every payment you process with the SDK must have a unique idempotency key.
    # If you're unsure whether a particular payment succeeded, you can reattempt
    # it with the same idempotency key without worrying about double charging
    # the buyer.
    "idempotency_key" => (string)$_SESSION['squareinvoiceid']
);
$invoiceId = $_SESSION['squareinvoiceid'];
# The SDK throws an exception if a Connect endpoint responds with anything besides
# a 200-level HTTP code. This block catches any exceptions that occur from the request.
try {
    //print_r($_POST);
    $result = $transaction_api->charge($access_token, $location_id, $request_body);
    //  print_r($result); exit();
    $response = $result->getTransaction()->getTenders();
    $responses = $response['0']->getTransactionId();
    $invoiceId = checkCbInvoiceID($_SESSION['squareinvoiceid'], $gateway['name']);
    $amount = ($response[0]->getAmountMoney()->getAmount() / 100);
    if (!$invoiceId) {
        exit('No Invoice is due');
    }
    checkCbTransID($responses);
    addInvoicePayment($invoiceId, $responses, ($response[0]->getAmountMoney()->getAmount() / 100), $fee, $gateway['name']);
    logTransaction($gateway['name'], $result, 'success');
    try {
        Capsule::table('mod_square_gateway')->insert(
                [
                    'invoiceid' => $invoiceId,
                    'tenderid' => $response['0']->getId()
                ]
        );
    } catch (\Exception $e) {
        echo "Unable to create my_table: {$e->getMessage()}";
    }
    header("Location:" . $gateway['systemurl'] . "/viewinvoice.php?id=" . $invoiceId);
} catch (\SquareConnect\ApiException $e) {
    logTransaction($gateway['name'], json_encode($e->getResponseBody()), "Error");
    $url = $gateway['systemurl'] . "/viewinvoice.php?id=" . $invoiceId . "&paymentfailed=true";
    header("location:" . $url);
}
exit();
